"""Prepare uploaded Baker–Janas–Kueng public Stata panels for descriptive research.
Usage: python prepare_bjk_panels.py --state BJK_State_Tax_Panel_public_v2.dta --county BJK_County_Tax_Panel_public.dta --out ./bjk_output
Produces provenance-preserving CSVs and machine-readable quality audit.
Original variable names, numeric units, zero and missing status are retained.
Not a causal policy shock dataset.
"""
import argparse, hashlib, json
from pathlib import Path
import pandas as pd

EXPECTED = {
    'state': ['state','stateabbr','fips','fipstate','year','corp_min_rate_state','corp_max_rate_state','sales_rate_state','prop_rate_state','corp_rate_state','gas_rate_state','spirit_rate_state','wine_rate_state','beer_rate_state','median_inc_rate_state','top_inc_rate_state'],
    'county': ['state','fips','state_fips','county_fips','year','prop_rate','sales_rate','mean_inc_rate'],
}

def process(name, source, out):
    data=pd.read_stata(source,convert_categoricals=False)
    if list(data.columns)!=EXPECTED[name]:
        raise ValueError(f'{name}: schema differs from reviewed source; refusing automatic import')
    keys=['stateabbr','year'] if name=='state' else ['fips','year']
    if data[keys].isna().any().any() or data.duplicated(keys).any():
        raise ValueError(f'{name}: missing or duplicate geographical-year key')
    if name=='state':
        if len(data)!=2448 or data.year.min()!=1975 or data.year.max()!=2022 or data.stateabbr.nunique()!=51:raise ValueError('state coverage differs from reviewed V2')
        if data[['fips','fipstate']].notna().all(axis=1).all() and not (data.fips==data.fipstate).all():raise ValueError('state FIPS mismatch')
    else:
        if len(data)!=71778 or data.year.min()!=2000 or data.year.max()!=2022 or data.state.nunique()!=51:raise ValueError('county coverage differs from reviewed source')
        if not (data.fips.astype(int)==data.state_fips.astype(int)*1000+data.county_fips.astype(int)).all():raise ValueError('county FIPS mismatch')
    data=data.sort_values(keys).reset_index(drop=True)
    output=out/f'bjk_{name}_tax_panel_descriptive.csv'
    data.to_csv(output,index=False,na_rep='',float_format='%.9g')
    parsed=pd.read_csv(output)
    if len(parsed)!=len(data):raise ValueError('CSV count mismatch')
    measures=[c for c in data.columns if c not in set(keys+(['state','fips','fipstate'] if name=='state' else ['state','state_fips','county_fips']))]
    audit={
        'source_file':Path(source).name, 'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),
        'output_file':output.name,'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'rows':len(data),'columns':list(data.columns),'keys':keys,'duplicate_keys':int(data.duplicated(keys).sum()),
        'year_min':int(data.year.min()),'year_max':int(data.year.max()),
        'jurisdictions':int(data.stateabbr.nunique() if name=='state' else data.state.nunique()),
        'missing_by_variable':{k:int(v) for k,v in data.isna().sum().items()},
        'measure_observed_by_variable':{k:int(data[k].notna().sum()) for k in measures},
        'measure_explicit_zero_by_variable':{k:int(data[k].eq(0).sum()) for k in measures},
        'notes':['Descriptive statutory and effective tax measures, not exogenous policy shocks.',
                 'Preserve original variable names and source-native units; do not sum different rate types.',
                 'Missing cells remain blank, distinguishable from explicit numeric zero.',
                 'Do not interpret year-to-year rate change as a uniquely identified enacted reform.',
                 'Version 2 state input required. County source retains published coverage limitations.',
                 'Reuse and redistribution require source license review.']}
    return audit

def main():
    a=argparse.ArgumentParser();a.add_argument('--state',required=True);a.add_argument('--county',required=True);a.add_argument('--out',default='bjk_output');p=a.parse_args()
    out=Path(p.out);out.mkdir(parents=True,exist_ok=True)
    report={'status':'VALIDATED_DESCRIPTIVE_IMPORT','research_ready_for_causality':False,
            'study':'Baker, Janas and Kueng, Correlation in State and Local Tax Changes, NBER Working Paper 32786',
            'sources':{name:process(name,getattr(p,name),out) for name in ('state','county')}}
    (out/'bjk_source_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({name:{k:v for k,v in audit.items() if k in ['rows','year_min','year_max','jurisdictions','duplicate_keys']} for name,audit in report['sources'].items()},indent=2))
if __name__=='__main__':main()
